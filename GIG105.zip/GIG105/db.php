<?php
// creatinng database connection
$servername = "localhost";
$username   = "root";
$password   = "icui4cu2";
$dbname     = "collegegig";

//create connection
$connect = new mysqli($servername, $username, $password, $dbname);

//check connection
 if($connect->connect_error)
 {
     die("connection failed: " .$conn->connect_error);
 }

else{
    mysqli_select_db($connect, $dbname);
}

?>