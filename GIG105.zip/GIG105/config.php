<?php
	include ('db.php');
        $name = $email= $comments ="";
    
        if($_SERVER["REQUEST_METHOD"] == "POST"){

		 $name = $_POST['name'];
		 $email = $_POST['email'];
  	     $comments = $_POST['comments'];

        }

// writing the sql query to send the value into the variables
	if(isset($_POST['submit']))
	{
           
 $sql="INSERT  INTO customer_info (name, email, comments)VALUES('$_POST[name]','$_POST[email]','$_POST[comments]')";


};

?>